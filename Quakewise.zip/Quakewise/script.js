const API_URL = "https://" + "earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson";
const earthquakeList = document.getElementById("earthquake-list");
const statusText = document.getElementById("status");
const lastUpdated = document.getElementById("last-updated");

const defaultLat = 20;
const defaultLng = 0;

const map = L.map("map", {
  preferCanvas: true
}).setView(L.latLng(defaultLat, defaultLng), 2);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors",
  maxZoom: 19
}).addTo(map);

const markersLayer = L.layerGroup().addTo(map);

async function loadEarthquakes() {
  statusText.textContent = "Fetching real earthquake data...";

  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error("Unable to fetch earthquake data");
    }

    const data = await response.json();

    earthquakeList.replaceChildren();
    markersLayer.clearLayers();

    // 1. Plot all earthquakes on the map
    data.features.forEach((earthquake) => {
      const [lng, lat] = earthquake.geometry.coordinates;
      const magnitude = earthquake.properties.mag;
      const place = earthquake.properties.place || "Unknown location";

      if (magnitude === null) return;

      L.circleMarker(L.latLng(lat, lng), {
        radius: Math.max(5, magnitude * 3),
        color: magnitude >= 4 ? "#ff4444" : "#38bdf8",
        fillOpacity: 0.7
      })
        .bindPopup(`<b>Magnitude:</b> ${magnitude}<br><b>Location:</b> ${place}`)
        .addTo(markersLayer);
    });

    // 2. Render the 20 most recent earthquake cards
    const recentQuakes = data.features.slice(0, 20);
    const fragment = document.createDocumentFragment();

    recentQuakes.forEach((earthquake) => {
      const info = earthquake.properties;
      const [, , depth] = earthquake.geometry.coordinates;

      const card = document.createElement("div");
      card.className = "earthquake-card";

      const magnitude = document.createElement("h3");
      magnitude.textContent = `Magnitude ${info.mag ?? "Unknown"}`;

      const location = document.createElement("p");
      location.textContent = info.place || "Unknown location";

      const depthText = document.createElement("p");
      depthText.textContent = `Depth: ${Number(depth).toFixed(1)} km`;

      const time = document.createElement("p");
      time.textContent = new Date(info.time).toLocaleString();

      const link = document.createElement("a");
      link.href = info.url;
      link.textContent = "View USGS report";
      link.target = "_blank";
      link.rel = "noopener noreferrer";

      card.append(magnitude, location, depthText, time, link);
      fragment.appendChild(card);
    });

    earthquakeList.appendChild(fragment);

    statusText.textContent = `${data.metadata.count} earthquakes reported in the past day (showing latest 20)`;
    lastUpdated.textContent = `Last updated: ${new Date().toLocaleTimeString()}`;
  } catch (error) {
    statusText.textContent = "Could not load data. Please check your internet connection.";
    console.error("Earthquake error:", error);
  }
}

loadEarthquakes();
setInterval(loadEarthquakes, 60000);